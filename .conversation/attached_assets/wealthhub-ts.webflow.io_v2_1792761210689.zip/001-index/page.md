[home](https://wealthhub-ts.webflow.io/)[Trading Community](https://wealthhub-ts.webflow.io/discord-community) [Strategy Vault](https://wealthhub-ts.webflow.io/magazine)

Research Hub

[Historical Data\\
\\
Vendor list](https://wealthhub-ts.webflow.io/historical-data-vendor-list) [Hedge Fund Letters\\
\\
Curated archive](https://wealthhub-ts.webflow.io/hedge-fund-letters) [Investment Mandates\\
\\
Tools for trading & backtesting](https://wealthhub-ts.webflow.io/institutional-mandates) [Recommended Reading\\
\\
Books on trading & investing](https://wealthhub-ts.webflow.io/books) [Machine Learning\\
\\
Courses for traders](https://wealthhub-ts.webflow.io/machine-learning-courses) [Research Papers\\
\\
Insights on strategy](https://wealthhub-ts.webflow.io/research-papers) [Financial Glossary\\
\\
Key terms explained](https://wealthhub-ts.webflow.io/glossary-stock-market) [Libraries for Quants\\
\\
Libraries, Packages and Resources](https://wealthhub-ts.webflow.io/complete-list-of-libraries-packages-and-resources-for-quants)

About Us

[Our Strategy Lab\\
\\
Custom models for funds](https://wealthhub-ts.webflow.io/about-us) [Contribute\\
\\
Submit your article](https://wealthhub-ts.webflow.io/contribute) [Career\\
\\
Join the team](https://wealthhub-ts.webflow.io/career)

[Articles](https://wealthhub-ts.webflow.io/articles)

[Contact Us\\
\\
Contact Us](https://wealthhub-ts.webflow.io/contact-us)

[Contact Us\\
\\
Contact Us](https://wealthhub-ts.webflow.io/contact-us)

🚀 Thriving Trading Community

# Wealth Hub - Where Traders Unite for     Confidence

Join a vibrant community where traders collaborate and share insights. Together, we empower each other to achieve financial success.

[Join Discord\\
\\
Join Discord](https://wealthhub-ts.webflow.io/#pricing)

![Area chart showing a rising trend with a final peak around 9.80 and a lower value near 9.52.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce141c_dashboard.avif)![Discord logo above text inviting to join an exclusive trading community for active traders with a blue join now button.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce141b_discord.avif)![List of market updates channels including options-flow, screeners, market-news, price-alert, and market-buzz with corresponding emojis.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce141a_market.avif)![Blue square with white text 'JPM' and a faint line graph in the background.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce1418_jpm.avif)![Financial summary showing May 4, 2025, portfolio value $312,643.55, SPY Benchmark +36% YTD, Strategy Return +246% YTD.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce1419_stats.avif)

powered by

![CME Group](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce161b_CME%20Group.avif)

![Quiver Quantitative](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce161a_Quiver.avif)

![TradingView](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce138e_TradingView.avif)

![OPENBB](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce1378_OPENBB.avif)

![Fiscal.ai](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce160f_Fiscal.ai.avif)

![InteractiveBrokers](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce1359_InteractiveBrokers.avif)

![Trade Station](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce1336_Trade%20Station.avif)

![CME Group](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce161b_CME%20Group.avif)

![Quiver Quantitative](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce161a_Quiver.avif)

![TradingView](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce138e_TradingView.avif)

![OPENBB](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce1378_OPENBB.avif)

![Fiscal.ai](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce160f_Fiscal.ai.avif)

![InteractiveBrokers](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce1359_InteractiveBrokers.avif)

![Trade Station](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce1336_Trade%20Station.avif)

![CME Group](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce161b_CME%20Group.avif)

![Quiver Quantitative](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce161a_Quiver.avif)

![TradingView](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce138e_TradingView.avif)

![OPENBB](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce1378_OPENBB.avif)

![Fiscal.ai](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce160f_Fiscal.ai.avif)

![InteractiveBrokers](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce1359_InteractiveBrokers.avif)

![Trade Station](https://cdn.prod.website-files.com/68f0faa809be102289ce125d/68f0faa809be102289ce1336_Trade%20Station.avif)

join

## Our Trading Community

What Awaits Inside the Wealth Hub

### Trade Ideas

Join a network of active traders sharing high-conviction setups and live technical breakdowns.

![Stock chart with candlestick patterns showing upward trend and a label indicating SPY stock increased by 260%.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce13e3_Trade%20Ideas.avif)

### Trading Community

Connect with serious traders and gain access to a supportive, resource-rich environment.

![Candlestick chart showing price fluctuations from May 10 to May 13 with values between $6,000 and $9,000 and a Discord logo at the top.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce13e4_Trading%20Community.avif)

### Discover Educational Resources

Explore trading tools, podcasts, and tutorials built to sharpen your skills.

### Never Miss Market   Moves

Instant notifications on  time sensitive trading opportunities.

## Smarter Trading Starts Here

Unlock the tools, insights, and community support you need to trade with confidence.

![Blue circular button with a white light bulb icon in the center.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12c8_Group%201000006858.avif)

### Exclusive Trading Insights

Join a community where cutting-edge data and real-time analysis drive smarter trading decisions.

![White flower icon on a blue circular button.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12cb_Group%201000006858.avif)

### AI-Powered Market Tools

Use intelligent tools to track sentiment, flow, and price action without the noise.

![White lightning bolt icon inside a blue circle.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12ca_Group%201000006858-1.avif)

### Instant Market Alerts

Stay one step ahead with real-time updates on key market shifts.

![White trophy icon centered on a blue circular background.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12c9_Group%201000006858-2.avif)

### Strategy Ideas

Explore high-quality research and ongoing trade ideas shared inside the community.

![White candlestick chart icon inside a speech bubble on a blue rounded square background.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12cc_Frame%202087326147.avif)

benefits

## Why Choose Wealth Hub?

Experience unparalleled trading support and insights.

![Blue gradient square showing a +113% increase with a line graph labeled QQQ.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce13dd_Discover%20the%20Wealth%20Hub%20Advantage.avif)

### Discover the Wealth Hub Advantage

Engage, learn, and succeed together.

![Digital portfolio card showing an account value of 788k with 38 total trades and a small bar graph.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce13e0_Smart%20Research%20Automation.avif)

### Smart Research Automation

Harness the power of our discord bots.

![Blue statistical bar graph showing daily monthly performance from Monday to Sunday.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce13df_Connect%20with%20Our%20Community.avif)

### Connect with Our Community

Collaborate and share insights with fellow traders.

![Line graph comparing SPY vs. QQQ from February to June with fluctuations in values.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce13de_Real%20Time%20Market%20Updates.avif)

### Real Time Market Updates

Dive into global market trends.

welcome

## Collaborative Trading Excellence

Explore our organized Discord knowledge categories.

![Symmetrical four-pointed star with gradient colors from purple to pink to orange.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12d1_Star%204.avif)

Channels

### Content Library

Access curated videos, podcasts, and advanced tools covering trader education.

![Sidebar menu displaying categories under Resources with podcasts-videos, education, tools, and Market Updates with options-flow, screeners, and market-news.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce142c_Content%20Library.avif)

### Trading Hub

Research-bot and trading-ideas channels for collaboration.

![Chat interface showing a trading hub with channels: research-bot, options, crypto, and trading-ideas, each with a related emoji.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce142e_Trading%20Hub.avif)

### Market Updates

Automatic real-time trend alerts for informed decisions.

![Line chart showing percentage values by month from February to August with a 49% volume spike in June and a Wealth Hub notification about a potential Bitcoin breakout.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce1429_Market%20Updates.avif)

![Symmetrical four-pointed star with gradient colors from purple to pink to orange.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12d1_Star%204.avif)

benefits

### Member Benefits

Unlock content and tools designed to sharpen your skills.

![Trading strategy performance chart showing a $275k value and 178.23% month-to-date increase with selectable time ranges from 1 hour to all time.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce13e8_Member%20Benefits.avif)

### Pro Lounge

Exlusive channel for like minded professional traders.

![Blue shield with the text 'PRO LOUNGE' centered inside, layered in front of larger translucent shield outlines.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12d4_Frame%201000006923.avif)

![Symmetrical four-pointed star with gradient colors from purple to pink to orange.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12d1_Star%204.avif)

Smart Signals

### AI Bot

Charts, dark pool data, crypto tracking, and scanning tools.

![Blue candlestick stock chart showing price movements with labels for AAPL and TSLA stocks.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce13e7_AI%20Bot.avif)

service launching soon

## Unlock 50% Off – Exclusive Early Access!

Be the first to join Wealth Hub and get 50% off! Offer available for a limited time only.

[Claim Your Spot & Save 50%\\
\\
Claim Your Spot & Save 50%](https://wealthhub-ts.webflow.io/#)

### Monthly Plan

## $39per month

Be the first to join Wealth Hub and get 50% off! Offer available for a limited time only.

[Coming soon](https://wealthhub-ts.webflow.io/#)

Paid monthly, cancel anytime

Real-time options flow, dark pool & short data alerts

Crypto dashboard with instant price and flow updates

Interactive charts, screeners & heat maps for quick analysis

Auto-updated economic calendar and macro indicators

Discovery channel for new trade ideas & opportunities

Weekly research digest + educational videos/tools

Community chat with Q&A sessions with the Wealth Hub team

### Annual

## $390per year

Be the first to join Wealth Hub and get 50% off! Offer available for a limited time only.

[Coming soon](https://wealthhub-ts.webflow.io/#)

Save 2 months

Everything in the Monthly plan

Quarterly deep-dive reports & asymmetric trade ideas

Access to Pro Lounge (pro-level market talk)

Unusual volume alerts  (reports & unusual volume alerts)

Government contracts & corporate lobbying updates

Early access to new tools & feature betas

Founding member badge

empower

## Real Strategies. No Hype.

Discover a collection of trading strategies. Whether you're refining your edge or building your first system, the Archive gives you direct access to what actually works.

![White upward trending bar chart icon on a blue circular background.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12f6_Group%201000006858.avif)

Trading Strategies

Across markets and timeframes

![Blue circular button with white code brackets symbols inside.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12fa_Group%201000006858-1.avif)

Code You Can Use

EasyLanguage & Python

![White open book icon on a blue circular background.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12f7_Group%201000006858-2.avif)

No-Fluff Research

Only tested concepts

![White graduation cap icon on a blue circular button.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12f8_Group%201000006858-3.avif)

Learn What Works

Lessons from history

![White ship helm icon on a blue circular background.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12f9_Group%201000006858-4.avif)

A Trader’s Toolbox

Strategies and backtest results

![Magazine titled WealthHub Archive Issue 1 with topics including Statistical Arbitrage in Action, Exploring Portfolio Efficiency, and Market Microstructure Tactics.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce131d_Magazine_Mockup_v01%201.avif)

![WealthHub Archive cover with topics: Find Your Edge with Smart Stats, Equal Weight Bigger Impact?, Momentum Moves That Work, and Issue 36.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce1435_34%201.avif)

### Wealth Hub Archive

Instant digital access. One time archive.

## $490One-time payment

36 full issues (PDF download)

500+ pages of content

Over 5,000 hours of research

Backtested Trading Strategies

[Coming soon](https://wealthhub-ts.webflow.io/#)

One-time payment

Address:

590 Madison Avenue New York, NY 10022

© Wealth Hub

Contact:

contact@wealthhubtrading.com

[Trading Community](https://wealthhub-ts.webflow.io/discord-community) [Strategy Vault](https://wealthhub-ts.webflow.io/magazine) [Free Articles](https://wealthhub-ts.webflow.io/magazine) [Financial Glossary](https://wealthhub-ts.webflow.io/glossary-stock-market) [Machine Learning Course](https://wealthhub-ts.webflow.io/machine-learning-courses) [Historical Data](https://wealthhub-ts.webflow.io/historical-data-vendor-list) [Hedge Fund Letters](https://wealthhub-ts.webflow.io/hedge-fund-letters) [Quant Libraries](https://wealthhub-ts.webflow.io/complete-list-of-libraries-packages-and-resources-for-quants)

[Recommended Reading](https://wealthhub-ts.webflow.io/books) [Machine Learning](https://wealthhub-ts.webflow.io/machine-learning-courses) [Research Papers](https://wealthhub-ts.webflow.io/research-papers) [Investment Mandates](https://wealthhub-ts.webflow.io/institutional-mandates) [Articles](https://wealthhub-ts.webflow.io/articles) [Our Strategy Lab](https://wealthhub-ts.webflow.io/about-us) [Contribute](https://wealthhub-ts.webflow.io/contribute) [Careers](https://wealthhub-ts.webflow.io/career)

Social

[X](https://x.com/wealthhub_hq) [LinkedIn](https://www.linkedin.com/company/wealthhubtrading/) [Medium](https://wealthhub.medium.com/) [GitHub](https://gist.github.com/18182324)

© 2025 Wealth Hub Capital. All rights reserved.

[Privacy Policy](https://wealthhub-ts.webflow.io/privacy-policy) [Terms of Service](https://wealthhub-ts.webflow.io/terms-of-service) [Legal Disclaimer](https://wealthhub-ts.webflow.io/legal-disclaimer)

Wealth Hub and its affiliated services provide educational content only. We do not offer investment advice, portfolio management, or any other service requiring registration or licensing under financial regulations. Nothing on this website, in our Discord community, or within the Wealth Hub Archive constitutes a recommendation, solicitation, or offer to buy or sell any financial instrument. All information is general in nature and for informational purposes only. Users are solely responsible for their own investment decisions and should consult a licensed financial advisor or registered investment professional before acting on any material provided. Use of this site implies acceptance of our full terms and conditions and legal disclaimers.

![Blue stylized icon of three vertical sliders inside a rounded rectangular frame, representing audio or settings controls.](https://cdn.prod.website-files.com/68f0faa809be102289ce1257/68f0faa809be102289ce12fd_Frame%201000006862.avif)